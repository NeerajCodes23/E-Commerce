﻿<?php
session_start();
if(isset($_SESSION['user_id'])){
  header('Location: 3_homePage.php');
}
if(!isset($_SESSION['error'])){
 $_SESSION['error']=null;}
 if(!isset($_COOKIE['cid'])){
  $_COOKIE['cid']=null;}
  if(!isset($_COOKIE['cpass'])){
    $_COOKIE['cpass']=null;}

?>
<!doctype html>
<html>
<head>

<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
   <style>
         html,body{width:100%;height:100%;}
         *{margin: 0px;} 
        .imga{height:20%;margin-top: 20px;margin-left: 20px;}
        div{margin:0px;display: inline-block;}
        .back{background-image: url(image/harry.jpg);
                 width: 30%;height:65%;
                background-repeat: no-repeat;  
                position: absolute;left:50%;
                top:58%;transform: translateY(-50%);  
        }
        .r1{border-radius:10px;outline:none;border-color:black;}
        .c2{position:absolute;
          top:28%;
           left:40%;
           transform:translatex(-50%);
         }
         input{ border:40;  height:30px;   text-align:center;  outline:none;margin-top:20px;}
   </style>

</head>
<img class="imga" src="image/logo&name1.png">
<div style="width:100%;height:70%;background-image: url(image/blu.png)">
<div class="back">
        <form class="c2" method="post"  name="f1" bgcolor="red" action="check_login.php">
                <p align="center" style="font-family: fantasy; font-size:20px;">Login to your account</p>
                <input class="r1" type="email" name="email" size="40" placeholder="email address" value="<?php echo $_COOKIE['cid'];?>" /></br>
                <input class="r1" type="password" name="password" size="40" placeholder="password" value="<?php echo $_COOKIE['cpass'];?>" /></br>
                <p id="error1" style="color:red;"><?php if($_SESSION['error']!=null) echo($_SESSION['error']);  ?> </p>
                <input type="checkbox" name="ch" value="chk1" style="position: relative;top:11px;"/><b>  remember me  </b></br>
                <input  style="border-radius:10%;cursor:pointer; color: cornsilk; border-color:black; font-family: 'Courier New', Courier, monospace border-radius:0px; 
                margin-left:50%;transform:translatex(-50%);background-color:red;"
                  type="submit" name="login_admin" value="             Login             ">
        </br></br><p style="margin-left: 70px;"><b> need an account? </b><a href="2_signup.php" style="text-decoration: crimson; color:brown"><b> Sign up </b></a></p>

           
            </form>

</div>
</div>


</html>