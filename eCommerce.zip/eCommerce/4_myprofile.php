<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
        <a href="https://icons8.com/icon/23280/administrator-male"></a>
        <!-- <a href="https://icons8.com/icon/20748/female-profile"></a> -->
        <a href="https://icons8.com/icon/40080/check"></a>
        <a href="https://icons8.com/icon/84898/male-user"></a>
        <a href="https://icons8.com/icon/83799/sign-out"></a>
        <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
   <style>
   html,body{width: 100%;height: 100%;}
   *{margin: 0px;}
   a{text-decoration: none; color:black;}
   .a1{font-family: 'Roboto', sans-serif;font-size: large;font-weight: bolder;font-size: 23px;cursor: pointer;}
   .a2{vertical-align:60%;margin-left:30%;font-family: 'Roboto', sans-serif; bolder;font-size: 18px;cursor: pointer;}
    .a3{font-family: 'Roboto', sans-serif;font-size: 20px;margin-left: 20px; margin-top: 20px;}
    .a4{width: 310px;height:30px;margin-left: 20px;margin-top: 15px; }
    .p1:hover{background-color:#a0bceb ;}
    .p2{background-color:#a0bceb ;}
   </style>
</head>
<body>
<div  style="width:100%; height:8%; background-color:black">
    <img onclick="redirect()"  src="image/lg2.png" style="height:100%;cursor:pointer;" />
  </div >
    <div style="width:20%;height:10%;background-color:;margin-top: 2%;margin-left: 2%;">
            <img src="https://img.icons8.com/color/48/000000/administrator-male.png" style="margin-left: 2%;margin-top:4%;">  
            <!-- <img src="https://img.icons8.com/color/48/000000/user-female-circle.png"> -->
            <h4 style="display: inline;vertical-align: 160%;margin-left: 26%; ">Hello</h4> 
    <br><p style="margin-top: -9%;margin-left: 60%;transform: translateX(-50%);font-size: 138%;
    font-family: 'Roboto', sans-serif; "><?php echo ($_SESSION["fn"]) ?></p>
     
    </div>
    <div style="width:20%;height:80%;background-color:;display: block;margin-top: 2%;margin-left: 2%;">
            <div class="p1" style="padding-top: 10px;"> <img src="https://img.icons8.com/metro/32/000000/check.png" style="margin-left: 3%;">
            <a class="a1"style=" vertical-align:40%;margin-left:14%;">My Orders</a>
            </div>
            <hr>
            <div > <img src="https://img.icons8.com/material/48/000000/user-male-circle.png">
                <a class="a1"style=" vertical-align:60%;margin-left:12%;">Account Settings</a>
            </div>
               <div class="p2" style="padding-top: 10px;"> <a class="a2"style=" ">Profile Information</a>
               </div>
               <div class="p1" style="padding-top: 10px;"> <a href="7_address.php" class="a2"style=" ">Manage Addresses</a>
               </div>
               <hr>
               <div class="p1"> <img src="https://img.icons8.com/material/48/000000/logout-rounded.png">
                <a class="a1"style=" color:black ; vertical-align:60%;margin-left:14%;">Log Out</a>
               </div>
                <hr>
    </div>

    <div  style="position: absolute;width:70%;height:92%;background-image: url(image/blu.png);top: 8%;left: 25%;color: white;">
      <h1 class="a3">Personal Information</h1>
      <input id="fn" class="a4" type="text" readonly ><input id="ln" class="a4" type="text"  readonly>
    <br><br>&nbsp;&nbsp;&nbsp;&nbsp; <b>Your Gender</b><br><br>
      &nbsp;&nbsp;&nbsp;&nbsp;<b>Male:&nbsp;&nbsp;<input type="checkbox" id="c1" disabled="disabled" > &nbsp;&nbsp;&nbsp;&nbsp;  Female:&nbsp;&nbsp;<input type="checkbox" id="c2" disabled="disabled">
      </b>
      <h1 class="a3">Email &nbsp; Address</h1>
      <input class="a4" type="text" id="email"  readonly>
      <h1 class="a3">Mobile &nbsp; Number</h1>
      <input class="a4" type="text" id="contact"  readonly ></br></br>
      <button style="margin-left:20px;cursor:pointer;" onclick="red()" >Edit Profile</button>
    </div>

    <script>
        w1= document.getElementById('fn');
        w2=document.getElementById('ln');
        w3=document.getElementById('c1');
        w4=document.getElementById('c2');
        w5= document.getElementById('email');
        w6=document.getElementById('contact');
        // w7=document.getElementById('c1');
        // w8=document.getElementById('c2');
        w1.value="<?php echo ($_SESSION["fn"]) ?>";
        w2.value="<?php echo ($_SESSION["ln"]) ?>";
        gen="<?php echo ($_SESSION["gender"]) ?>";
        if(gen=="male"){
            w3.checked="yes";
        }
        else{
          w4.checked="yes";
        }
        w5.value="<?php echo ($_SESSION["user_name"]) ?>";
        w6.value="<?php echo ($_SESSION["contact"]) ?>";
       function redirect(){
        window.location.href = '3_homePage.php';

       }
       function red(){
        window.location.href ='edit_profile.php';
       }
    </script>
    
</body>
</html>