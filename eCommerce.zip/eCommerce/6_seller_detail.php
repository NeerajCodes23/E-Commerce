<?php
session_start();
?>
<!DOCTYPE html>
<html>
<head>
    <style>
          html, body {width: 100%;height: 100%;}
    *{ margin: 0px;}
    .imga{height:20%;margin-top: 20px;margin-left: 20px;}

    
.f1{
	max-width: 500px;
    max-height: 700px;
	background: #FAFAFA;
	padding: 5pxpx;
	margin:50px auto;

	box-shadow: 1px 1px 25px rgba(0, 0, 0, 0.35);
	border-radius: 10px;
	border: 6px solid #305A72;
}
input,select{margin-right: 10px;width:45%;padding-bottom: 6px;
    padding-top: 6px;
    font-size: 17px;}
ul{padding: 0px;}
textarea{margin-right: 10px;width:99%;

   height: 100px;
}
input[type="submit"]{width: 100%; }
 li{list-style: none;padding: 10px 5px 10px 5px;}

</style>
    </style>
</head>
<body style="background-image:url(image/blu.png)">
    <img class="imga" src="image/logo&name1.png">
    <form class="f1">
            <ul>
            <li>
                <input type="text" id="acc_number" placeholder="Account Number" />
                <input type="text" id="ifsc_code"  placeholder="IFSC Code" />
            
            </li>
            <li>
                <select id="state">
                    <option value="">Select State</option>
                    <option value="Andhra Pradesh">Andhra Pradesh</option>
                    <option value="Arunachal Pradesh">Arunachal Pradesh</option>
                    <option value="Assam">Assam</option>
                    <option value="Bihar">Bihar</option>
                    <option value="Chhattisgarh">Chhattisgarh</option>
                    <option value="Delhi">Delhi</option>
                    <option value="Goa">Goa</option>
                    <option value="Gujarat">Gujarat</option>
                    <option value="Haryana">Haryana</option>
                    <option value="Himachal Pradesh">Himachal Pradesh</option>
                    <option value="Jammu and Kashmir">Jammu and Kashmir</option>
                    <option value="Jharkhand">Jharkhand</option>
                    <option value="Karnataka">Karnataka</option>
                    <option value="Kerala">Kerala</option>
                    <option value="Lakshadweep">Lakshadweep</option>
                    <option value="Madhya Pradesh">Madhya Pradesh</option>
                    <option value="Maharashtra">Maharashtra</option>
                    <option value="Manipur">Manipur</option>
                    <option value="Meghalaya">Meghalaya</option>
                    <option value="Mizoram">Mizoram</option>
                    <option value="Nagaland">Nagaland</option>
                    <option value="Orissa">Orissa</option>
                    <option value="Pondicherry">Pondicherry</option>
                    <option value="Punjab">Punjab</option>
                    <option value="Rajasthan">Rajasthan</option>
                    <option value="Sikkim">Sikkim</option>
                    <option value="Tamil Nadu">Tamil Nadu</option>
                    <option value="Tripura">Tripura</option>
                    <option value="Uttaranchal">Uttaranchal</option>
                    <option value="Uttar Pradesh">Uttar Pradesh</option>
                    <option value="West Bengal">West Bengal</option>
                    </select>
                <input type="text" id="pincode"  placeholder="Pin Code" />
            </li>
            <li>
            <input type="text" id="city"  placeholder="City" />
            <input type="text" id="company"  placeholder="Company Name" />
            </li>
          
            <li>
            <textarea id="pickup_address"  placeholder="Pickup Address"></textarea>
            </li>
            <li>
            <input type="button" onclick="insert_detail()" value="Continue" />
            </li>
            </ul>
            </form>

            <script>
               function insert_detail(){
                a1 = document.getElementById('acc_number').value;
                     a2= document.getElementById('ifsc_code').value;
                     a3 = document.getElementById('pincode').value;
                     a4 = document.getElementById('city').value;
                     a5 = document.getElementById('pickup_address').value;
                     a6=document.getElementById('state').value;
                     a7=document.getElementById('company').value;
                     cx= new XMLHttpRequest();
                     if(cx){
                       cx.open("POST","http://localhost/eCommerce/insert_seller_details.php", true);

                      cx.onreadystatechange = () =>{
                        if(cx.readyState == 4){
                          console.log("cx response text", cx.responseText);
                        }

                      }
                      cx.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
                      cx.send("acc_number="+a1+"&ifsc_code="+a2+
                      "&pincode="+a3+"&city="+a4+"&pickup_address="+a5+"&state="+a6+"&company="+a7);
                     
                     document.location.href ="9_seller_dashboard.php";
                     }
                     
      }

  </script>
    
</body>
</html>