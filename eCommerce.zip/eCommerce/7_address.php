<?php
session_start();
?>

<!DOCTYPE html>
<html>
<head>
        <a href="https://icons8.com/icon/23280/administrator-male"></a>
        <!-- <a href="https://icons8.com/icon/20748/female-profile"></a> -->
        <a href="https://icons8.com/icon/40080/check"></a>
        <a href="https://icons8.com/icon/84898/male-user"></a>
        <a href="https://icons8.com/icon/83799/sign-out"></a>
        <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
        <a href="https://icons8.com/icon/xAf1bLrTU4GS/delete-bin"></a>
        <!-- <a href="https://icons8.com/icon/11153/plus-math"></a>
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css"> -->
   <style>
   html,body{width: 100%;height: 100%;}
   *{margin: 0px;}
   .a1{font-family: 'Roboto', sans-serif;font-size: large;font-weight: bolder;font-size: 23px;cursor: pointer;}
   .a2{vertical-align:60%;margin-left:30%;font-family: 'Roboto', sans-serif; bolder;font-size: 18px;cursor: pointer;}
   a{text-decoration: none; color:black;}
   .p1:hover{background-color:#a0bceb  ;}
    .p2{background-color:#a0bceb;}
    .c1{display: inline-block; width:30%;height:200px; margin-left: 20px; margin-top: 20px;border-color: darkgray; border-radius: 5px;
     vertical-align: top;}

   </style>
</head>
<body>
<div  style="width:100%; height:8%; background-color:black">
    <img onclick="redirect()"  src="image/lg2.png" style="height:100%;cursor:pointer;" />
  </div >
    <div style="width:20%;height:10%;background-color:;margin-top: 2%;margin-left: 2%;">
            <img src="https://img.icons8.com/color/48/000000/administrator-male.png" style="margin-left: 2%;margin-top:4%;">  
            <!-- <img src="https://img.icons8.com/color/48/000000/user-female-circle.png"> -->
            <h4 style="display: inline;vertical-align: 160%;margin-left: 26%; ">Hello</h4> 
    <br><p style="margin-top: -9%;margin-left: 60%;transform: translateX(-50%);font-size: 138%;
    font-family: 'Roboto', sans-serif; "><?php echo ($_SESSION["fn"]) ?></p>
     
    </div>
    <div style="width:20%;height:80%;background-color:;display: block;margin-top: 2%;margin-left: 2%;">
            <div class="p1" style="padding-top: 10px;"> <img src="https://img.icons8.com/metro/32/000000/check.png" style="margin-left: 3%;">
            <a class="a1"style=" vertical-align:40%;margin-left:14%;">My Orders</a>
            </div>
            <hr>
            <div > <img src="https://img.icons8.com/material/48/000000/user-male-circle.png">
                <a class="a1"style=" vertical-align:60%;margin-left:12%;">Account Settings</a>
            </div>
               <div class="p1" style="padding-top: 10px;"> <a href="4_myprofile.php" class="a2"style=" ">Profile Information</a>
               </div>
               <div class="p2" style="padding-top: 10px;"> <a  class="a2"style=" ">Manage Addresses</a>
               </div>
               <hr>
               <div class="p1"> <img src="https://img.icons8.com/material/48/000000/logout-rounded.png">
                <a class="a1"style=" color:black ; vertical-align:60%;margin-left:14%;">Log Out</a>
               </div>
                <hr>
    </div>

  
      <div  style="position: absolute;width:70%;top: 10%;left: 25%;color: black; border: 1px solid black;">
        <div class="c1" style="   border-style: dashed;border-width: 3px;padding: 0px;">
           <a  href="8_shipping_address.php" style="cursor: pointer">   <img src="https://img.icons8.com/ios/50/000000/plus-math.png" style="margin-left:50px;    position: absolute;
                left: 90px;top: 80px; ">  
           </a>  
         <h2 style="margin-left: 80px;margin-top:42%; color:black;">Add Address</h2>
        </div>
       <?php

          $con=mysqli_connect("localhost","root","","cartsea",3306);
              if(!$con){
                 die("cant connect to database");
                }
        $p=$_SESSION['user_id'];
        $sql="select * from user_address_details where user_id='$p'";
        $res=mysqli_query($con,$sql);
         if($res){
           
          
         
              while($data=mysqli_fetch_assoc($res)){
                ?>
                <div class="c1"style="    border-style: solid;border-width: 3px;"> 
                <?php
              echo nl2br("$data[full_name] \nContact: $data[contact]\n $data[street_address] \n$data[landmark] \n $data[city] $data[state]\n Pin: $data[pin_code]");
              ?> </br><a href="del_add.php?id=<?php echo($data['address_number']);    ?>"> <img  style="cursor:pointer"  src="https://img.icons8.com/windows/32/000000/delete-forever.png"/></a>    </div>  
               <?php
                }
              }
              ?>
              
              
            </br></br></br>
        
      </div>
      <script>
      function redirect(){
        window.location.href = '3_homePage.php';
       } 
       function del(){


       }
      </script>
  </body>
  </html>