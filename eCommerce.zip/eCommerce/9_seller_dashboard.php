<?php
session_start();

?>
<!DOCTYPE html>
<html>

<head>
<link href="https://fonts.googleapis.com/css?family=Russo+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="styles.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="script.js"></script>  

  <style>
    html,
    body {
      width: 100%;
      height: 100%;
    }
    
    * {
      margin: 0px;
    }
     
   
   </style>
</head>

<body>
<div id='cssmenu' bgcolor="black">
<ul>
   <li class='active'><a href='#'><span>Dashboard</span></a></li>
   <li><a href='seller_product.php'><span>My Products</span></a></li>
   <li><a href='seller_order.php'><span>Orders</span></a></li>
   <li><a href='logout_seller.php'><span>Log Out</span></a></li>
   <li style="position:absolute;right:100px;"><a  style="font-size:40px;font-family: 'Russo One', sans-serif;
   padding:20px;background-color:blue;"><span>Seller's Point</span></a></li>
</ul>

</div>


</body>
</html>