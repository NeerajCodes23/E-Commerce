<html>
<head>

<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<style>
  html,body{width:100%;height:100%;}
  input,select{border-width:2px;margin:10px;height:25px;width:70%;border-color:black;border-radius:10px;outline:none;}
  textarea{margin:10px;height:50px;width:70%;border-color:black;border-radius:10px;border-width:2px;} 
.label1{ padding:10px;margin-bottom:20px;font-family: 'Roboto', sans-serif;}
.fs{margin-left:25%; width:70%;}
</style>

</head>
<body>

<form class="fs" action="add_product_db.php"  method="POST" enctype="multipart/form-data">


<!-- Form Name -->
<legend style="color:white;background-color:black;width:70%;height:50px;font-size:40px;">&nbsp;&nbsp;&nbsp;&nbsp;Add Product</legend>
<br><br>


<!-- Text input-->
<div >
  <label class="label1" for="product_name">PRODUCT NAME</label>  
  <div >
  <input id="product_name" name="product_name" required="" type="text">
    
  </div>
</div>
<div >
  <label class="label1" for="product_name">PRODUCT BRAND</label>  
  <div >
  <input id="product_brand" name="product_brand" required="" type="text">
    
  </div>
</div>
<!-- Text input-->
<div>
  <label class="label1" for="product_name_fr">PRODUCT DESCRIPTION</label>  
  <div >
  <input id="product_description" name="product_description"  required="" type="text">
    
  </div>
</div>

<!-- Select Basic -->
<div >
  <label class="label1" >PRODUCT CATEGORY</label>
  <div >
    <select id="product_category" name="product_category" style="width:30%;" >
    <option value="0">Electronics</option>
    <option value="1">Edibles</option>
     <option value="2">Men</option>
    <option value="3">Women</option> 
    <option value="4">Baby & Kids</option>
    <option value="5">Home & Furniture</option>
     <option value="6">Sports,Books&More</option>
    

    </select>
  </div>
</div>

<!-- Text input-->
<div >
  <label class="label1" >AVAILABLE QUANTITY</label>  
  <div>
  <input id="available_quantity" name="available_quantity" required="" type="text">
    
  </div>
</div>

<!-- Text input-->
<div >
  <label class="label1" >PRODUCT WEIGHT</label>  
  <div class="col-md-4">
  <input id="product_weight" name="product_weight" placeholder="  if necessary(in Kg)"  type="text">
    
  </div>
</div>

<!-- Textarea -->
<div >
  <label class="label1">PRODUCT DETAILS</label>
  <div >                     
    <textarea  id="product_details" name="product_details"></textarea>
  </div>
</div>

<div >
  <label class="label1" >PRODUCT PRICE</label>  
  <div>
  <input id="product_price"  name="product_price"  required="" type="text">
    
  </div>
</div>


<!-- Text input-->
<div >
  <label class="label1" >PERCENTAGE DISCOUNT</label>  
  <div>
  <input id="percentage_discount" name="percentage_discount"  placeholder="  in %"  required="" type="text">
    
  </div>
</div>



 <!-- File Button --> 
<div >
  <label class="label1" >IMAGE</label>
  <div>
    <input id="file"  name="file"   style="cursor:pointer;"  type="file">
  </div>
</div>

<input type="submit"  value="ADD"  style="cursor:pointer;background-color:black;color:white;border-color:black;" >
<script>
            function delivery_function(){
                  
                     a1 = document.getElementById('product_name').value;
                     a2= document.getElementById('product_description').value;
                     a3 = document.getElementById('product_category').value;
                     a4 = document.getElementById('available_quantity').value;
                     a5 = document.getElementById('product_weight').value;
                     a6 = document.getElementById('product_details').value;
                     a7 = document.getElementById('percentage_discount').value;
                     a8 = document.getElementById('filebutton').value;
                     a9 = document.getElementById('product_price').value;
                     a10= document.getElementById('product_brand').value;
                     
                   
                     cx= new XMLHttpRequest();
                     if(cx){
                       cx.open("POST","http://localhost/eCommerce/add_product_db.php", true);

                      cx.onreadystatechange = () =>{
                        if(cx.readyState == 4){
                          console.log("cx response text", cx.responseText);
                        }

                      }
                      cx.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
                      cx.send("product_name="+a1+"&product_description="+a2+
                      "&product_category="+a3+"&available_quantity="+a4+"&product_weight="+a5+"&product_details="
                      +a6+"&percentage_discount="+a7+"&filebutton="+a8+"&product_price="+a9+"&product_brand="+a9);
                       document.location.href = "seller_product.php";
                     }
                     

            }
            
            </script>
            
        <br> <br> <br>


</form>
<body>
</html>