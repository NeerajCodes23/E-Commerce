<?php
session_start();
$seller_id= $_SESSION["seller_id"];
$product_name=$_POST['product_name'];
$product_brand=$_POST['product_brand'];
$product_description=$_POST['product_description'];
 $product_category=$_POST['product_category'];
 $available_quantity=$_POST['available_quantity'];
 $product_weight=$_POST['product_weight'];
 $product_price=$_POST['product_price'];

 $product_details=$_POST['product_details'];
 $percentage_discount=$_POST['percentage_discount'];
 if($_FILES["file"]["size"]>0){
     if($_FILES["file"]["error"]>0){
         echo( code.$_FILES["file"]["error"]."<br>");
     }
     else{
         echo("upload".$_FILES["file"]["name"]."</br>");
         echo("type ".$_FILES["file"]["type"]."</br>");
         echo("size ".($_FILES["file"]["size"]/1024)."Kb</br>");
         echo("temp file ".$_FILES["file"]["tmp_name"]."</br>");
              
          if(file_exists("upload".$_FILES["file"]["name"])){
              echo($_FILES['file']['name']."already exists");
          }
          else{
              $path="upload/".$_FILES["file"]["name"];
              $temp=$_FILES["file"]["tmp_name"];
              move_uploaded_file($temp,$path);
              echo "stored in :".$path;

          }
               

     }
 }
 else{
     echo "invalid file";
 }



$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
     echo($seller_id.$product_brand.$available_quantity.$product_description.$product_price.$percentage_discount.$product_weight.$product_category.$path.$product_details.$product_name);
$sql="INSERT INTO `product`(`seller_id`,`product_brand_name`, `product_quantity`, `product_description`, `product_price`,
 `discount`, `product_weight`, `product_category_id`, `product_image`,  `product_details`, `product_name`)
  VALUES
 ('$seller_id','$product_brand','$available_quantity','$product_description','$product_price','$percentage_discount',
 '$product_weight','$product_category','$path',' $product_details','$product_name')";
$res=mysqli_query($con,$sql);
 if($res){  header('Location: seller_product.php');


        }
        else{
            error_log(mysqli_error($con),3,"error.txt");
        echo "noooo";}



?>