<html>
<head>

<link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
<style>
  html,body{width:100%;height:100%;}
  input,select{border-width:2px;margin:10px;height:25px;width:70%;border-color:black;border-radius:10px;outline:none;}
  textarea{margin:10px;height:50px;width:70%;border-color:black;border-radius:10px;border-width:2px;} 
.label1{ padding:10px;margin-bottom:20px;font-family: 'Roboto', sans-serif;}
.fs{margin-left:25%; width:70%;}
</style>

</head>
<body>

<form class="fs" action="add_product_db.php"  method="POST" enctype="multipart/form-data">


<!-- Form Name -->
<legend style="color:white;background-color:black;width:70%;height:50px;font-size:40px;">&nbsp;&nbsp;&nbsp;&nbsp;Add Student</legend>
<br><br>


<!-- Text input-->
<div >
  <label class="label1" for="product_name">First Name</label>  
  <div >
  <input id="product_name" name="first_name" required="" type="text">
    
  </div>
</div>
<div >
  <label class="label1" for="product_name">Last NAME</label>  
  <div >
  <input id="product_name" name="last_name" required="" type="text">
    
  </div>
</div>
<div >
  <label class="label1" for="product_name">Course Name</label>  
  <div >
  <input id="product_brand" name="course_name" required="" type="text">
    
  </div>
</div>


<div >
  <label class="label1">Address</label>
  <div >                     
    <textarea  id="product_details" name="address"></textarea>
  </div>
</div>

<!-- Text input-->
<div >
  <label class="label1" >City</label>  
  <div>
  <input id="available_quantity" name="city" required="" type="text">
    
  </div>
</div>
<div >
  <label class="label1" >State</label>  
  <div>
  <input id="available_quantity" name="state" required="" type="text">
    
  </div>
</div>




<div >
  <label class="label1" >Mobile Number</label>  
  <div>
  <input id="product_price"  name="product_price"  required="" type="text">
    
  </div>
</div>




<input type="submit"  value="ADD"  style="cursor:pointer;background-color:black;color:white;border-color:black;" >
<script>
            function delivery_function(){
                  
                     a1 = document.getElementById('product_name').value;
                     a2= document.getElementById('product_description').value;
                     a3 = document.getElementById('product_category').value;
                     a4 = document.getElementById('available_quantity').value;
                     a5 = document.getElementById('product_weight').value;
                     a6 = document.getElementById('product_details').value;
                     a7 = document.getElementById('percentage_discount').value;
                     a8 = document.getElementById('filebutton').value;
                     a9 = document.getElementById('product_price').value;
                     a10= document.getElementById('product_brand').value;
                     
                   
                     cx= new XMLHttpRequest();
                     if(cx){
                       cx.open("POST","http://localhost/eCommerce/add_product_db.php", true);

                      cx.onreadystatechange = () =>{
                        if(cx.readyState == 4){
                          console.log("cx response text", cx.responseText);
                        }

                      }
                      cx.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
                      cx.send("product_name="+a1+"&product_description="+a2+
                      "&product_category="+a3+"&available_quantity="+a4+"&product_weight="+a5+"&product_details="
                      +a6+"&percentage_discount="+a7+"&filebutton="+a8+"&product_price="+a9+"&product_brand="+a9);
                       document.location.href = "seller_product.php";
                     }
                     

            }
            
            </script>
            
        <br> <br> <br>


</form>
<body>
</html>