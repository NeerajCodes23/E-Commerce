<?php
session_start();

?>
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="3_css.css">
    <link rel="stylesheet" href="3_homecss.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
  <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
  <style>
    html,
    body {
      width: 100%;
      height: 100%;
    }
    
    * {
      margin: 0px;
    }

   
   </style>
</head>

<body>
  <div style="width:100%; height:8%; background-color:black">
    <img src="image/lg2.png" style="height:100%;" />
    <form class="example" action="action_page.php" style="width:50%;height:100%; display: inline-block;">
      <input type="text" class="abc1" placeholder="  Search for products..." name="search">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
    