<?php
session_start();
$uid=$_SESSION['user_id'];
$seller_quantity=$_GET['sq'];
$z=$_GET['p_id'];
$p_name=$_GET['p_name'];
$p_brand=$_GET['p_brand'];
$p_price=$_GET['p_price'];
$p_seller=$_GET['p_seller'];
$p_cat=$_GET['p_cat'];
$c_price=$_GET['c_price'];
$p_discount=$_GET['p_discount'];
$p_image=$_GET['p_image'];


?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="buypage_css.css">
<link href="https://fonts.googleapis.com/css?family=Merriweather|Roboto&display=swap" rel="stylesheet">  <style>
    html,body { width: 100%;height: 100%;}
    * {margin: 0px;}
    .bp1{ font-size:16px;font-family: 'Roboto', sans-serif; margin-left:10px;margin-top:10px;}
   </style>
</head>

<body bgcolor="#edebe6" >
<div  style="width:100%; height:8%; background-color:black">
    <img onclick="redirect()"  src="image/lg2.png" style="height:100%;cursor:pointer;" />
  </div >

  <div style="background-color:white;width:43%;margin-top:80px;margin-left:60px;"> 
    <div style="background-color:blue;width:100%;height:50px;border-radius:4px;">
   <br> <p style="margin-left:20px;margin-top: -2px;font-family: sans-serif;font-weight: 600;font-size: 18px;color:white;">DELIVERY ADDRESS</p>
    </div> 
<?php
    $con=mysqli_connect("localhost","root","","cartsea",3306);
    if(!$con){
       die("cant connect to database");
      }
$p=$_SESSION['user_id'];
$sql="select * from user_address_details where user_id='$p'";
$res=mysqli_query($con,$sql);
$num=mysqli_num_rows($res);
if($num!=0){
    while($data=mysqli_fetch_assoc($res)){
      $an=$data['address_number'];$n=$data['address_type'];
      if($n=='0'){$at="Home";}
      if($n=='1'){$at="Office";}
      $x=$data['street_address']." ".$data['landmark']." ".$data['city']." ".$data['state']; ;
      
      ?>



  <div>
     <h1 class="bp1">
      <input style="height:16px;vertical-align: sub; width:15px;margin-top:10px;" type="radio" name="address" id="myadd" onclick="setval(<?php echo($an); ?>)"
       checked value="<?php echo($an); ?>">&nbsp;&nbsp;<?php echo($data['full_name']); ?>&nbsp;
       <b style="font-size: 12px;background-color:cyan;color: blue;"><?php echo($at); ?></b>&nbsp;<?php echo($data['contact']); ?></h1>
      <h1 class="bp1" style="font-size:13px;margin-top:5px;"><?php echo($x); ?></h1>
      <h1 class="bp1" style="font-size:13px;margin-top:5px;"><?php echo($data['pin_code']); ?></h1>
       <br><hr style="height:1px; border:0px; background: #333; background-image: linear-gradient(to right, #ccc, #333, #ccc);">

  </div>
    <?php
    } }
    else{ ?> <h1 class="bp1" style="font-size:13px;margin-top:5px;">Go to 'Manage Addresses' and add an address</h1> <?php
    }
    ?>
   
  </div>

  <div style="background-color:white;position:absolute;left:50%;top:134px;border-radius:5px;width:45%;height:50%;">
  <div style="background-color:blue;width:100%;height:50px;border-radius:4px;">
   <br> <p style="margin-left:20px;margin-top: -2px;font-family: sans-serif;font-weight: 600;font-size: 18px;color:white;">Order Summary</p>
    </div> 
    <h1 class="bp1" style="font-size:20px;margin-top:0px;text-transform:capitalize;"><?php echo($p_name); ?><p style="display:inline;font-size:14px;"> &nbsp;&nbsp;[<?php echo($p_brand); ?>]</p></h1>
    <h1 class="bp1" style="font-size:9px;margin-top:0px;text-transform:capitalize;"><?php echo($p_cat); ?></h1>
    <h1 class="bp1" style="font-size:13px;margin-top:4px;text-transform:capitalize;font-family: 'Merriweather', serif;">
    Seller: <?php echo($p_seller); ?></h1>

    <h5 style="font-size:25px;margin-left:10px;font-family: 'Roboto', sans-serif;text-transform:capitalize;"><?php
  echo("₹".$p_price); ?>&nbsp;&nbsp; <s style="color:brown;font-size:15px"><?php echo("₹".$c_price); ?>  </s>
  <p style="font-size:15px;color:green;display:inline;">&nbsp;&nbsp;<?php echo("$p_discount"); ?>% Off  </p> </h5>
  <form>
  <div class="value-button" id="decrease" onclick="decreaseValue(<?php echo($p_price); ?>)" value="Decrease Value">-</div>
  <input type="number" id="number" value="1" />
  <div class="value-button" id="increase" onclick="increaseValue(<?php echo($p_price); ?>)" value="Increase Value">+</div>
</form>
<p id="warning" style="color:red;margin-left:10px;"></p>
</br>
<div style="background-color:blue;width:100%;height:50px;border-radius:4px;">
   <br> <p style="margin-left:20px;margin-top: -2px;font-family: sans-serif;font-weight: 600;font-size: 18px;color:white;">Bill Detail</p>
    </div> 
    <h1 class="bp1" id="hey" style="font-size:20px;margin-top:8px;text-transform:capitalize;">Total Payable: <?php echo("₹".$p_price); ?></h1>
    <div style="background-color:green;width:100%;height:50px;border-radius:4px;margin-top:20px;">
   <br> <p style="margin-left:20px;margin-top: -2px;font-family: sans-serif;font-weight: 600;font-size: 18px;color:white;">Order Now</p>
    </div> </br>
    <button class="button" id="b1" onclick="handleorder('<?php echo($an)?>','<?php echo($uid)?>','<?php echo($seller_quantity)?>','<?php echo($z)?>','<?php echo($p_name);?>','<?php echo($p_brand);?>',
    '<?php echo($p_price);?>','<?php echo($p_seller);?>','<?php echo($p_cat);?>','<?php echo($c_price);?>','<?php echo($p_discount);?>','<?php echo($p_image);?>')" 
    style="vertical-align:middle"><span>Order </span></button>

  </div>





  <script>
  var value1=0;
      function increaseValue(p) {
        kk=document.getElementById('warning');
        kk.innerHTML="";
  var value = parseInt(document.getElementById('number').value, 10);
  elem=document.getElementById('hey');
  value = isNaN(value) ? 0 : value;
  value++;
  document.getElementById('number').value = value;
  z=parseInt(p);
  x=z*value;
elem.innerHTML="Total Payable: ₹"+x;
}

function decreaseValue(p) {
  kk=document.getElementById('warning');
        kk.innerHTML="";
  var value = parseInt(document.getElementById('number').value, 10);
  elem=document.getElementById('hey');
  value = isNaN(value) ? 0 : value;
  value < 1 ? value = 1 : '';
  value--;
  document.getElementById('number').value = value;
  z=parseInt(p);
  x=z*value;
elem.innerHTML="Total Payable: ₹"+x;
}
function setval(z){
  window.value1=z;
}



   function handleorder(ff,uid,sq,pid,p_name,p_brand,s_price,p_seller,p_cat,c_price,p_discount,p_image){
     if(window.value1==0){
       window.value1=ff;
     }
    i=document.getElementById('number').value;
    ff=document.getElementById("myadd").value;
    console.log("hhhhhhhhhhhh");
    console.log(window.value1);
    console.log("jjjjj");
    console.log(ff);
    if(i>sq){
        kk=document.getElementById('warning');
        kk.innerHTML="Sorry "+sq+" products left.";
       }
       else{
         left1=sq-i;
    s=document.getElementById('b1');
    console.log("sdfghgfdsdfgh");
             console.log(uid+pid+p_name+p_brand,+s_price+p_seller+p_cat+c_price+p_discount);
			 s.innerHTML="Ordered";
			 s.style.backgroundColor="green";
     
     
      
			 cx= new XMLHttpRequest();
                     if(cx){
                       cx.open("POST","http://localhost/eCommerce/orderdirect.php", true);

                      cx.onreadystatechange = () =>{
                        if(cx.readyState == 4){
                          console.log("cx response text", cx.responseText);
                        }

                      }
                      cx.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
                      cx.send("add_num="+window.value1+"user_id="+uid+"lft="+left1+"&p_id="+pid+"&p_name="+p_name+"&p_brand="+p_brand+
      "&s_price="+s_price+"&p_seller="+p_seller+"&p_cat="+p_cat+"&c_price="+c_price+"&p_discount="+p_discount+"&p_image="+p_image+"&p_quantity="+i);
					 }
           else{
            error_log(mysqli_error($con),3,"error.txt");
       }
         }   

   }

   function redirect(){
        window.location.href = '3_homePage.php';

       } 
  </script>

</body>

</html>