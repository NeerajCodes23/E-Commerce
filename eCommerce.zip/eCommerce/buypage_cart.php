<?php
session_start();


?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="buypage_css.css">
<link href="https://fonts.googleapis.com/css?family=Merriweather|Roboto&display=swap" rel="stylesheet">  <style>
    html,body { width: 100%;height: 100%;}
    * {margin: 0px;}
    .bp1{ font-size:16px;font-family: 'Roboto', sans-serif; margin-left:10px;margin-top:10px;}
   </style>
</head>

<body bgcolor="#edebe6" >
<div style="width:100%; height:8%; background-color:black">
    <img src="image/lg2.png" style="height:100%;" />
  </div >

  <div style="background-color:white;width:43%;margin-top:80px;margin-left:60px;"> 
    <div style="background-color:blue;width:100%;height:50px;border-radius:4px;">
   <br> <p style="margin-left:20px;margin-top: -2px;font-family: sans-serif;font-weight: 600;font-size: 18px;color:white;">DELIVERY ADDRESS</p>
    </div> 

    <?php
    $con=mysqli_connect("localhost","root","","cartsea",3306);
    if(!$con){
       die("cant connect to database");
      }
$p=$_SESSION['user_id'];
$sql="select * from user_address_details where user_id='$p'";
$res=mysqli_query($con,$sql);
$num=mysqli_num_rows($res);
if($num!=0){
    while($data=mysqli_fetch_assoc($res)){
      $an=$data['address_number'];$n=$data['address_type'];
      if($n=='0'){$at="Home";}
      if($n=='1'){$at="Office";}
      $x=$data['street_address']." ".$data['landmark']." ".$data['city']." ".$data['state']; ;
      ?>



  <div>
     <h1 class="bp1">
      <input style="height:16px;vertical-align: sub; width:15px;margin-top:10px;" type="radio" checked name="address" value="<?php echo($an); ?>">&nbsp;&nbsp;<?php echo($data['full_name']); ?>&nbsp;
       <b style="font-size: 12px;background-color:cyan;color: blue;"><?php echo($at); ?></b>&nbsp;<?php echo($data['contact']); ?></h1>
      <h1 class="bp1" style="font-size:13px;margin-top:5px;"><?php echo($x); ?></h1>
      <h1 class="bp1" style="font-size:13px;margin-top:5px;"><?php echo($data['pin_code']); ?></h1>
       <br><hr style="height:1px; border:0px; background: #333; background-image: linear-gradient(to right, #ccc, #333, #ccc);">

  </div>
    <?php
    } }
    else{ ?> <h1 class="bp1" style="font-size:13px;margin-top:5px;">Go to 'Manage Addresses' and add an address</h1> <?php
    }
    ?>
   
  </div>

  <div style="background-color:white;position:absolute;left:50%;top:134px;border-radius:5px;width:45%;height:50%;">
  <div style="background-color:blue;width:100%;height:50px;border-radius:4px;">
   <br> <p style="margin-left:20px;margin-top: -2px;font-family: sans-serif;font-weight: 600;font-size: 18px;color:white;">Order Summary</p>
    </div> 
    <?php
    $con=mysqli_connect("localhost","root","","cartsea",3306);
    if(!$con){
       die("cant connect to database");
      }
$sql="select * from cart where user_id='$p'";
$res=mysqli_query($con,$sql);
$num=mysqli_num_rows($res);
if($num!=0){$total=0;
    while($data=mysqli_fetch_assoc($res)){
        $total=$total+($data['s_price']*$data['product_quantity']); 
      ?>



<div>
    <h1 class="bp1" style="font-size:20px;margin-top:0px;text-transform:capitalize;"><?php echo($data['p_name']); ?><p style="display:inline;font-size:14px;"> &nbsp;&nbsp;[<?php echo($data['p_brand_name']); ?>]</p></h1>
    <h1 class="bp1" style="font-size:9px;margin-top:0px;text-transform:capitalize;"><?php echo($data['p_category']); ?></h1>
    <h1 class="bp1" style="font-size:15px;margin-top:0px;text-transform:capitalize;">Quantity: <?php echo($data['product_quantity']); ?></h1>
    <h1 class="bp1" style="font-size:13px;margin-top:4px;text-transform:capitalize;font-family: 'Merriweather', serif;">
    Seller: <?php echo($data['seller']); ?></h1>

    <h5 style="font-size:25px;margin-left:10px;font-family: 'Roboto', sans-serif;text-transform:capitalize;"><?php
  echo("₹".$data['s_price']); ?>&nbsp;&nbsp; <s style="color:brown;font-size:15px"><?php echo("₹".$data['c_price']); ?>  </s>
  <p style="font-size:15px;color:green;display:inline;">&nbsp;&nbsp;<?php echo($data['p_discount']); ?>% Off  </p> </h5>
 
</div>
    <?php
    } }
    else{ ?> <h1 class="bp1" style="font-size:13px;margin-top:5px;">Nothing to buy</h1> <?php
    }
    ?>




<div style="background-color:blue;width:100%;height:50px;border-radius:4px;">
   <br> <p style="margin-left:20px;margin-top: -2px;font-family: sans-serif;font-weight: 600;font-size: 18px;color:white;">Bill Detail</p>
    </div> 
    <h1 class="bp1" id="hey" style="font-size:20px;margin-top:8px;text-transform:capitalize;">Total Payable: <?php echo("₹".$total); ?></h1>
    <div style="background-color:green;width:100%;height:50px;border-radius:4px;margin-top:20px;">
   <br> <p style="margin-left:20px;margin-top: -2px;font-family: sans-serif;font-weight: 600;font-size: 18px;color:white;">Order Now</p>
    </div> </br>
    <button class="button" style="vertical-align:middle"><span>Order </span></button>

  </div>

  



  <script>
  
  </script>

</body>

</html>