<?php
session_start();
$user_id= $_SESSION["user_id"];
$cart_id=$_POST['cart_id'];
$cart_quantity=$_POST['quantity'];


$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="UPDATE cart
SET product_quantity =$cart_quantity WHERE cart_id='$cart_id' AND user_id='$user_id'";
$sql1="delete from cart where product_quantity=0";
$res=mysqli_query($con,$sql);
$res1=mysqli_query($con,$sql1);
 if($res){ 
             
          
        }
        else{
            error_log(mysqli_error($con),3,"error.txt");}
       
        if($res1){ 
             
          
        }
        else{
            error_log(mysqli_error($con),3,"error.txt");
          echo "noooooooo";
        }

?>