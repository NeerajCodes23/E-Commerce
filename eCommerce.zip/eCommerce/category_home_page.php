<?php
session_start();
$w=$_GET["w"];
switch ($w) {
    case "0":
       $catname="electronics";  break;
    case "1":
        $catname="edibles";  break;
    case "2":
        $catname="men";  break;
    case "3":
      $catname="women";  break;
    case "4":
       $catname="baby";  break;
    case "5":
       $catname="furniture";  break;
    case "6":
       $catname="others";  break;
  }
?>
<!DOCTYPE html>
<html>

<head>
    <link rel="stylesheet" href="3_css.css">
    <link rel="stylesheet" href="3_homecss.css">
    <link href="https://fonts.googleapis.com/css?family=Oxygen&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Quicksand|Squada+One&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <link href="https://fonts.googleapis.com/css?family=Roboto&display=swap" rel="stylesheet">
 
  <style>
    html,
    body {
      width: 100%;
      height: 100%;
    }
    
    * {
      margin: 0px;
    }
     .card{border: 2px solid brown;width:250px;height:350px;display:inline;float:left;margin-left:40px;padding-bottom:6px;cursor:pointer;margin-bottom:10px;}
      
   </style>
</head>

<body onload="colorit('<?php echo($catname); ?>')">
  <div style="width:100%; height:8%; background-color:black">
    <img src="image/lg2.png" onclick="redirect_homepage()" style="height:100%;cursor:pointer;" />
    <form class="example" action="search.php" method="POST" style="width:50%;height:100%; display: inline-block;">
      <input type="text" class="abc1" placeholder="  Search for products..." name="qwer">
      <button type="submit"><i class="fa fa-search"></i></button>
    </form>
    <ul class="ul1">

      
          <li  class="dropdown">
            <?php
             if(!isset($_SESSION['user_id'])){
             ?>
              <a href="1_signin.php" style="text-decoration:none;" class="dropbtn"><?php
             
             echo "Login";?></a><?php }
             else{ ?>
                 <a  class="dropbtn"><?php
                 echo ($_SESSION["fn"]);?></a>

             
             
              <div class="dropdown-content">
                <a href="4_myprofile.php">My Profile</a>
                <a href="myorder.php">My Orders</a>
                <a href="mycart.php">My Cart</a>
                <a href="logout.php">Log Out</a>
              </div>
            </li>
      <li   class="main_list"><a >More</a> </li>

      <li  class="main_list"><a style="text-decoration:none;" href="mycart.php">Cart</a></li>
             <?php  }  ?>
            
    </ul>
  </div>
<div>
  <ul>
  <li class="q"> <a  onclick="display_category(0)" name="electronics">Electronics</a></li>
      <li class="q"> <a   onclick="display_category(1)" name="edibles">Edibles</a></li>
      <li class="q"> <a  onclick="display_category(2)" name="men">Men</a></li>
      <li class="q"><a  onclick="display_category(3)" name="women">Women</a></li>
       <li class="q" > <a  onclick="display_category(4)" name="baby">Baby & Kids</a></li>
       <li class="q" > <a   onclick="display_category(5)" name="furniture">Home & Furniture</a></li>
       <li class="q" > <a  onclick="display_category(6)" name="others">Sports,Books& More</a></li>
      
  </ul>
</div>

 
 <div class="slideshow-container">

  
  <div class="mySlides fade">
    <img src="image/1.png" style="">
    <div class="text">Caption Text</div>
  </div>

  <div class="mySlides fade">
    <img src="image/2.png" style="">
    <div class="text">Caption Two</div>
  </div>


  <a class="prev" onclick="plusSlides(-1)">&#10094;</a>
  <a class="next" onclick="plusSlides(1)">&#10095;</a>
</div>
<br> 


<?php

$con=mysqli_connect("localhost","root","","cartsea",3306);
    if(!$con){
       die("cant connect to database");
      }
$p=$_SESSION['user_id'];
$sql="select * from product where product_category_id=$w";
$res=mysqli_query($con,$sql);
if($res){
 


    while($data=mysqli_fetch_assoc($res)){
      $l=$data['product_id'];
      ?>
        
        <div class="card" style="" onclick="display_page(<?php echo($data['product_id']); ?>)">
   <img style="width:250px;height:250px;margin-left:50%;transform:translateX(-50%);" src="<?php echo("http://localhost/eCommerce/".$data['product_image']);?>">
   <h5 style="font-size:15px;margin-left:10px;color:brown;font-family: 'Squada One', cursive;text-transform:capitalize;">
   <?php echo($data['product_brand_name']); ?></h5>

   <h5 style="font-size:22px;margin-left:10px;font-family: 'Roboto', sans-serif;text-transform:capitalize;"><?php echo($data['product_name']); ?></h5>
   <h5 style="font-size:12px;margin-left:10px;color:darkgoldenrod;font-family: 'Oxygen', sans-serif;text-transform:capitalize;"><?php echo($data['product_description']); ?></h5>
   </br>
   <h5 style="font-size:20px;margin-left:10px;font-family: 'Roboto', sans-serif;text-transform:capitalize;"><?php
   $d=$data['discount'];
   $d=100-$d;
   $n_price =round(($data['product_price']/ 100) * $d);
   echo("₹".$n_price); ?> <s style="color:brown;">&nbsp;<?php echo("₹".$data['product_price']); ?> </s>
   <p style="font-size:15px;color:green;display:inline;">&nbsp;&nbsp;&nbsp;<?php echo($data['discount']."% Off"); ?> </p> </h5></br>
  </div>
<?php
    }
    }
    ?>

<br>
<br>
<br>
<br>


<script>

  var slideIndex = 1;
  showSlides(slideIndex);
  
  function plusSlides(n) {
    showSlides(slideIndex += n);
  }
  
  function currentSlide(n) {
    showSlides(slideIndex = n);
  }
  
  function showSlides(n) {
    var i;
    var slides = document.getElementsByClassName("mySlides");
    if (n > slides.length) {slideIndex = 1}    
    if (n < 1) {slideIndex = slides.length}
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
   
    slides[slideIndex-1].style.display = "block";  

  }
    function display_page(pid){
    //  $_SESSION['hp']=pid;
      console.log("pid ", pid);
      window.location.href ="product_buy.php?pid="+pid;

    }

    function display_category(w){
      window.location.href="category_home_page.php?w="+w;
      
      
    }
    function redirect_homepage(){
      window.location.href="3_homepage.php";
    }
    function colorit(q){
      console.log(q);
    var rt= document.getElementsByName(q);
    rt[0].style["color"] = "blue"; 
    console.log("llll");
    }
  </script>
  

</body>

</html>