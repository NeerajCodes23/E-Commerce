<?php
session_start();
$em=$_POST['email'];
$pass=$_POST['password'];

echo "dfgfdfgfd";
$con=mysqli_connect("localhost","root","","student",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="select *from admin where email='$em' AND password='$pass' ";
$res=mysqli_query($con,$sql);
if (mysqli_num_rows($res)!= 0)
{
              if($data=mysqli_fetch_assoc($res)){ 
                $xyz=$data['admin_id'];
                $_SESSION["email"] =$em;
                $_SESSION['admin_id'] = $xyz;
                $_SESSION["full_name"] = $data['full_name'];
                $_SESSION["password"] =$data['password'];
                $_SESSION["mobile_number"]=$data['mobile_number'];
                echo "yessssssss";
               
                header("Location: admin_dashboard.php");
              
                } 

}
 else{ 
       $_SESSION['error1']="email and password did'nt match";
      echo "eeeeeeeeeeeeeee";

}







?>