<?php
session_start();
$em=$_POST['email'];
$pass=$_POST['password'];


$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="select *from user where user_email_id='$em' AND user_password='$pass' ";
$res=mysqli_query($con,$sql);
if (mysqli_num_rows($res)!= 0)
{
              if($data=mysqli_fetch_assoc($res)){ 
                $xyz=$data['user_id'];
                echo($xyz);
                 echo($em);
                $_SESSION["user_name"] =$em;
                $_SESSION["user_id"] = $xyz;
                $_SESSION["fn"] = $data[user_first_name];
                $_SESSION["ln"] =$data[user_last_name];
                $_SESSION["contact"]=$data[user_mobile_number];
                $_SESSION["password"]=$data[user_password];
                $_SESSION["gender"]=$data[user_gender];
                $_SESSION['error']=null;



                		
               			
                if($_POST['ch']==true)			
                {			
                setcookie("cid",$em,time()+60*60);			
                setcookie("cpass",$pass,time()+60*60);						
                }			
               header('Location: 3_homePage.php');
                } 
           


}
else{ $_SESSION['error']="email and password did'nt match";
     header('Location: 1_signin.php');

}







?>