<?php
session_start();
$id = $_GET['id']; 
$con=mysqli_connect("localhost","root","","cartsea",3306);
    if(!$con){
       die("cant connect to database");
      }
$p=$_SESSION['user_id'];
$sql="delete from user_address_details where address_number=$id";
$res=mysqli_query($con,$sql);
if($res){
   $data=mysqli_fetch_assoc($res);

   header('Location: 7_address.php');
} 

?>