<?php
session_start();
$con=mysqli_connect("localhost","root","","cartsea",3306);
    if(!$con){
       die("cant connect to database");
      }
$p=$_SESSION['user_id'];
$sql="select * from user where user_id='$p'";
$res=mysqli_query($con,$sql);
if($res){
 $data=mysqli_fetch_assoc($res);
 
}

?>

<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
body {
  font-family: Arial, Helvetica, sans-serif;
  background-color: white;
}

* {
  box-sizing: border-box;
}

/* Add padding to containers */
.container {
    width:70%;
    margin:auto;
  padding: 16px;
  /* background-color: white; */
  border-color:black;
  border-width:4px;
}

/* Full-width input fields */
input[type=text], input[type=password] {
  width: 100%;
  padding: 15px;
  margin: 5px 0 22px 0;
  display: inline-block;
  border: none;
  background: #f1f1f1;
}

input[type=text]:focus, input[type=password]:focus {
  background-color: #ddd;
  outline: none;
}

/* Overwrite default styles of hr */
hr {
  border: 1px solid #f1f1f1;
  margin-bottom: 25px;
}

/* Set a style for the submit button */
.registerbtn {
  background-color: #4CAF50;
  color: white;
  padding: 16px 20px;
  margin: 8px 0;
  border: none;
  cursor: pointer;
  width: 100%;
  opacity: 0.9;
}

.registerbtn:hover {
  opacity: 1;
}

/* Add a blue text color to links */
a {
  color: dodgerblue;
}

/* Set a grey background color and center the text of the "sign in" section */
.signin {
  background-color: #f1f1f1;
  text-align: center;
}
</style>
</head>
<body>

<form action="save_changes.php" method="POST" style="border-color:black; border: 4px solid black;
  border-radius: 4px; width:70%;margin:auto;">
  <div class="container">
    <h1>Edit Profile</h1>
    <hr>

    <label for="email"><b>First Name</b></label>
    <input type="text" value="<?php echo($data['user_first_name']); ?>"  name="fn" >

    <label ><b>Last Name</b></label>
    <input type="text" value="<?php echo($data['user_last_name']); ?>"  name="ln">
    <label ><b>Mobile Number</b></label>
    <input type="text" value="<?php echo($data['user_mobile_number']); ?>"  name="mb" >
    <label ><b>Password</b></label>
    <input type="password" value="<?php echo($data['user_password']); ?>"  name="pass" >
    <hr>
    <button type="submit" class="registerbtn">Save Changes</button>
  </div>
  
</form>

</body>
</html>
