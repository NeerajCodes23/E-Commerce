<!DOCTYPE html>
<html>
<body>
            <script>
                
            function delivery_function(){
                    console.log("in function");
                    //  var fd = new FormData( document.getElementById("fs") );
                    //  xyz =document.getElementByName("full_name").innerHTML;
                     cx= new XMLHttpRequest();
                     if(cx){
                       cx.open("GET","http://localhost/eCommerce/insert_address.php?fname=gfd", true);

                      cx.onreadystatechange = () =>{
                        if(cx.readyState == 4){
                          console.log("cx response text", cx.responseText);
                        }

                      }
                      //cx.setRequestHeader("Content-type", "application/x-www-form-urlencoded");
                      cx.send();

                     }
                 
            }
            delivery_function();
            </script>
        <br> <br> <br>
                
</body>
</html>