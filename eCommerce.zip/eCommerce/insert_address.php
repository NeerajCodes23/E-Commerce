<?php
session_start();
echo $_POST['street1'];
$z=$_POST['type'];
if($z=="home"){$n=0;}
if($z=="office"){$n=1;}
$add=$_POST['street1']." ".$_POST['street2'];
$contact=$_POST['countrycode'].$_POST['contact'];
$user_id= $_SESSION["user_id"];
$full_name=$_POST['full_name'];
$landmark=$_POST['landmark'];
 $city=$_POST['city'];
 $state=$_POST['state'];
 $pincode=$_POST['pincode'];
$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="INSERT INTO `user_address_details`(`user_id`, `full_name`, `street_address`, `landmark`, `contact`,
 `city`, `state`, `pin_code`, `address_type`) VALUES ('$user_id','$full_name','$add','$landmark','$contact',
 '$city','$state','$pincode',$n)";
$res=mysqli_query($con,$sql);
 if($res){  echo "yss ";      
        }
        else{error_log(mysqli_error($con),3,"error.txt");}



?>