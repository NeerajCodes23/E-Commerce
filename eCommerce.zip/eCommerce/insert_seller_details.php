<?php
session_start();
$sid=$_SESSION['seller_id'];
$acc_number=$_POST['acc_number'];
$ifsc_code=$_POST['ifsc_code'];
$pincode=$_POST['pincode'];
$city=$_POST['city'];
$pickup_address=$_POST['pickup_address'];
$state=$_POST['state'];
$company=$_POST['company'];
$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="update seller set pincode='$pincode',account_number='$acc_number',ifsc_code='$ifsc_code',
 state='$state', city='$city',pickup_address='$pickup_address',company_name='$company' where seller_id='$sid'";
$res=mysqli_query($con,$sql);
 if($res){  echo "yss ";      
        }
        else{error_log(mysqli_error($con),3,"error.txt");}

      


?>