<?php
session_start();
$contact=$_POST['countrycode'].$_POST['contact'];
$full_name=$_POST['full_name'];
$_SESSION['full_name']=$_POST['full_name'];
$email=$_POST['email'];
$password=$_POST['password'];
$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="INSERT INTO `seller`( `full_name`, `email`, `contact`, `password`)
 VALUES ('$full_name','$email','$contact','$password')";
$res=mysqli_query($con,$sql);
 if($res){     
    $con1=mysqli_connect("localhost","root","","cartsea",3306);
    if(!$con1){
        die("cant connect to database");
        }
  $sql1="select seller_id from seller where contact=$contact ";
  $res1=mysqli_query($con1,$sql1);
  if (mysqli_num_rows($res1)!= 0)
  {
                if($data=mysqli_fetch_assoc($res1)){ 
                  $xyz=$data['seller_id'];
                  $_SESSION['seller_id']=$xyz;
                  } 
  
  }
   else{error_log(mysqli_error($con),3,"error.txt");}   
        }
        else{error_log(mysqli_error($con),3,"error.txt");}

      


?>