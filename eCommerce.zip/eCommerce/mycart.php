<?php
session_start();

$p=$_SESSION['user_id'];
?>
<!DOCTYPE html>
<html>
<head>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

        <link href="https://fonts.googleapis.com/css?family=Notable|Patua+One|Roboto&display=swap" rel="stylesheet">
  <style>
     html,body{height:100%;width:100%;}
    *{margin:0px;}
    .bp1{ font-size:16px;font-family: 'Roboto', sans-serif; margin-left:10px;margin-top:2px;}
     .pk{text-transform:capitalize;text-align:center;}
     form {
  width: 300px;
  margin: 0 auto;
  text-align: center;
  padding-top: -1px;
}

.value-button {
  display: inline-block;
  border: 1px solid #ddd;
  margin: 0px;
  width: 40px;
  height: 42px;
  text-align: center;
  vertical-align: middle;
  padding: 11px 0;
  background: #eee;
  -webkit-touch-callout: none;
  -webkit-user-select: none;
  -khtml-user-select: none;
  -moz-user-select: none;
  -ms-user-select: none;
  user-select: none;
}

.value-button:hover {
  cursor: pointer;
}

form #decrease {
  margin-right: -4px;
  border-radius: 8px 0 0 8px;
}

form #increase {
  margin-left: -4px;
  border-radius: 0 8px 8px 0;
}

form #input-wrap {
  margin: 0px;
  padding: 0px;
}

input#number {
  text-align: center;
  border: none;
  border-top: 1px solid #ddd;
  border-bottom: 1px solid #ddd;
  margin: 0px;
  width: 40px;
  height: 40px;
}

input[type=number]::-webkit-inner-spin-button,
input[type=number]::-webkit-outer-spin-button {
    -webkit-appearance: none;
    margin: 0;
}
.button {
  
  border-radius: 4px;
  background-color: red;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 12px;
  width: 35%;
  transition: all 0.5s;
  cursor: pointer;
  margin-bottom:20px;
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
  </style>
</head>
<body bgcolor="#edebe6" >
<div  style="width:100%; height:8%; background-color:black">
    <img onclick="redirect()"  src="image/lg2.png" style="height:100%;cursor:pointer;" />
  </div >


<div style="display:block";>
<?php
    $con=mysqli_connect("localhost","root","","cartsea",3306);
    if(!$con){
       die("cant connect to database");
      }
$p=$_SESSION['user_id'];
$sql="select * from user_address_details where user_id='$p'";
$res=mysqli_query($con,$sql);
$num=mysqli_num_rows($res);
if($num!=0){
    while($data=mysqli_fetch_assoc($res)){
      $an=$data['address_number'];$n=$data['address_type'];
      if($n=='0'){$at="Home";}
      if($n=='1'){$at="Office";}
      $x=$data['street_address']." ".$data['landmark']." ".$data['city']." ".$data['state']; ;
      
      ?>



  <div style="margin-top:0px;">
     <h1 class="bp1">
      <input style="height:12px;vertical-align: sub; width:15px;margin-top:2px;" type="radio" name="address" id="myadd" onclick="setval(<?php echo($an); ?>)"
       checked value="<?php echo($an); ?>">&nbsp;&nbsp;<?php echo($data['full_name']); ?>&nbsp;
       <b style="font-size: 12px;background-color:cyan;color: blue;"><?php echo($at); ?></b>&nbsp;<?php echo($data['contact']); ?></h1>
      <h1 class="bp1" style="font-size:13px;margin-top:5px;"><?php echo($x); ?></h1>
      <h1 class="bp1" style="font-size:13px;margin-top:5px;"><?php echo($data['pin_code']); ?></h1>
       <hr style="height:1px; border:0px; background: #333; background-image: linear-gradient(to right, #ccc, #333, #ccc);">

  </div>
    <?php
    } }
    else{ ?> <h1 class="bp1" style="font-size:13px;margin-top:5px;">Go to 'Manage Addresses' and add an address</h1> <?php
    }
    ?>
   
  </div>








            <div style="width:100%; height:8%; background-color:white; width:85%;height:50%;margin-top:40px;margin-left:110px;   ">
                    <div style="background-color:orange;width:100%;height:50px;border-radius:4px; border: 2px solid;">
                             <p style=" text-align:center;font-family: 'Russo One', sans-serif;font-size: 37px;" >MY CART</p>                                                                                    

                    </div> 
                    
                    
                    <div class="container" >
                            <div class="table-responsive">          
                            <table class="table">
                              <thead>
                                 <tr style="font-size:18px;">
                                    <th class="pk">Product Image</th>
                                    <th class="pk">Product Name</th>
                                    <th class="pk">Product Quantity</th>  
                                    <th class="pk">Product Price</th>
                                    <th class="pk">Discount(%)</th>
                                    <th class="pk">Sold By</th>

                                   
                                </tr>
                               </thead>
                            <tbody>
                           
                           <?php
                                $con=mysqli_connect("localhost","root","","cartsea",3306);
                                if(!$con){
                                   die("cant connect to database");
                                  }
                             $sql="select * from cart where user_id='$p'";
                            
                              $res=mysqli_query($con,$sql);
                              if($res){         $u=-1;$total=0;
                                while($data=mysqli_fetch_assoc($res)){
                                  $q=$data["p_image"];$cc=$data['cart_id'];++$u;$total=$total+($data['s_price']*$data['product_quantity']);

                                  $sql1="select * from product where product_id='$data[product_id]'";
                            
                                  $res1=mysqli_query($con,$sql1);
                                  $data1=mysqli_fetch_assoc($res1);
                                        $pc=$data1['product_quantity'];

                                  ?>
                                  <tbody>
                                   <tr>
                                             <td class="pk"><img style="width:200px;height:200px;margin-left:50%;transform:translateX(-50%);" src="<?php echo("http://localhost/eCommerce/".$q);?>"></td>
                                             <td class="pk" style="vertical-align: inherit;"><?php echo($data['p_name']); ?></td>
                                             <td  class="pk" style="vertical-align: inherit;">
                                             <form>
  <div class="value-button" id="decrease" onclick="decreaseValue(<?php echo($data['cart_id']); ?>,<?php echo($u); ?>,<?php echo($data['s_price']); ?>)" value="Decrease Value">-</div>
  <input type="number" name="number" id="number" value="<?php echo($data['product_quantity']); ?>" />
  <div class="value-button" id="increase" onclick="increaseValue(<?php echo($pc); ?>,<?php echo($data['cart_id']); ?>,<?php echo($u); ?>,<?php echo($data['s_price']); ?>)" value="Increase Value">+</div>
</form>
                                            </td>
                                             <td  class="pk" style="vertical-align: inherit;"><?php echo("₹".$data['s_price']); ?></td>
                                             <td class="pk"  style="vertical-align: inherit;"><?php echo($data['p_discount']."%"); ?></td>
                                             <td class="pk"  style="vertical-align: inherit;"><?php echo($data['seller']); ?></td>
                                             <!-- <td><img src="<?php echo("http://localhost/eCommerce/".$q);?>" alt="" border=3 height=50 width=50></img></td> -->
                                             
                            </tr></tbody>
                                 <?php 
                                }}
                                else{echo "noooooooooo";}
                                ?> 
                            </table></div></div>     
                            <div style="background-color: yellow;width: 35%;height: 45px;;border-radius:4px; border: 2px solid;">
                             <p style=" text-align:center;font-family: fantasy;font-size: 30px;" >TOTAL VALUE: ₹<b id="money" style="display:inline;"><?php echo($total); ?> </b></p>

                    </div></br>
                    <button id="b1" class="button" onclick="woof()" style="vertical-align:middle;display:inline;"><span>Order </span></button></br>

                </div></div>




    <script>
    var value1=0;
    function setval(z){
  window.value1=z;
}
 function redirect(){
        window.location.href = '3_homePage.php';

       }  
    function woof(){
      s=document.getElementById('b1');
    console.log("sdfghgfdsdfgh");
           
			 s.innerHTML="Ordered";
			 s.style.backgroundColor="green";
      cx= new XMLHttpRequest();
                     if(cx){
                       cx.open("POST","http://localhost/eCommerce/orderviacart.php", true);

                      cx.onreadystatechange = () =>{
                        if(cx.readyState == 4){
                          console.log("cx response text", cx.responseText);
                         

                        }}
                      cx.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
                      cx.send("add_num="+window.value1);
                      window.location.href="mycart.php";
					 }
           else{
            error_log(mysqli_error($con),3,"error.txt");
            alert("hiiiiii");
       }
           

      
    }
    function  c1(x,value){
        cx= new XMLHttpRequest();
                     if(cx){
                       cx.open("POST","http://localhost/eCommerce/cartquantity.php", true);

                      cx.onreadystatechange = () =>{
                        if(cx.readyState == 4){
                          console.log("cx response text", cx.responseText);
                         

                        }

                      }
                      cx.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
                      cx.send("cart_id="+x+"&quantity="+value);
					 }
           else{
            error_log(mysqli_error($con),3,"error.txt");
       }
           

      }


      function increaseValue(pc,x,y,sp) {
  var n = parseInt(document.getElementsByName('number')[y].value);

  n = isNaN(n) ? 0 : n;
  n++;
  if(n>pc){
    n=pc;
    document.getElementsByName('number')[y].value = n;
  }
  else{
  document.getElementsByName('number')[y].value = n;

c1(x,n);
      d=parseInt(document.getElementById('money').innerHTML);
      d=d+sp;
      document.getElementById('money').innerHTML=d;}
   
}

function decreaseValue(x,y,sp) {
  var i = parseInt(document.getElementsByName('number')[y].value);
  d=parseInt(document.getElementById('money').innerHTML);
     if(i>0)
    d=d-sp;
    else{}
  i= isNaN(i) ? 0 : i;
  i < 1 ? i = 1 : '';
  i--;
  document.getElementsByName('number')[y].value = i;
c1(x,i);

    document.getElementById('money').innerHTML=d;
}
    
    </script>
</body>
</html>