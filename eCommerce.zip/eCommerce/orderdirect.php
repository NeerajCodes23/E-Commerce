<?php
session_start();
$user_id= $_SESSION["user_id"];
$lft=$_POST['lft'];
$con=mysqli_connect("localhost","root","","cartsea",3306);

$sql3="select * from user_address_details where user_id='$user_id' and address_number='$_POST[add_num]'   ";
$res3=mysqli_query($con,$sql3);
$data3=mysqli_fetch_assoc($res3);

if(!$con){
     die("cant connect to database");
     }
     $sql1="INSERT INTO `orders`(`user_id`, `product_id`, `product_quantity`,  `p_name`, `p_brand_name`, `p_discount`, `s_price`, `p_image`, `p_category`, `p_seller`,
      `address_id`, `address_type`, `customer_name`, `street_address`, `landmark`, `contact`, `city`, `state`, `pincode`) VALUES
     ('$user_id','$_POST[p_id]','$_POST[p_quantity]','$_POST[p_name]','$_POST[p_brand]','$_POST[p_discount]','$_POST[s_price]',' $_POST[p_image]','$_POST[p_cat]',
     '$_POST[p_seller]','$_POST[add_num]','$data3[address_type]','$data3[full_name]','$data3[street_address]',
     '$data3[landmark]','$data3[contact]','$data3[city]','$data3[state]','$data3[pin_code]'  )";
   $res1=mysqli_query($con,$sql1);

 if($res1){ 
          echo("yessssssss");
          $sql2="delete from cart where product_id='$_POST[p_id]'";
          $res2=mysqli_query($con,$sql2);

        }
        else{ echo("nooooooooooooooo");
            error_log(mysqli_error($con),3,"error.txt");}

        
            $sql2="UPDATE `product` set product_quantity='$lft' where product_id=$_POST[p_id] ";
          $res2=mysqli_query($con,$sql2);
       
      

?>