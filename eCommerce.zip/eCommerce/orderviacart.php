<?php
session_start();
$user_id= $_SESSION["user_id"];
$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
     $sql6="select * from user_address_details where user_id='$user_id' and address_number='$_POST[add_num]'   ";
     $res6=mysqli_query($con,$sql6);
     $data6=mysqli_fetch_assoc($res6);


$sql="select * from cart where user_id='$user_id'";
$res=mysqli_query($con,$sql);
 if($res){ 
    while($data=mysqli_fetch_assoc($res)){
        $p_image=$data["p_image"];
        $p_id=$data['product_id'];
        $p_name=$data['p_name'];
        $p_quantity=$data['product_quantity'];
        $p_brand=$data['p_brand_name'];
        $s_price=$data['s_price'];
        $p_seller=$data['seller'];
        $p_cat=$data['p_category'];
        $p_discount=$data['p_discount'];
        echo($p_quantity);
        $sql1="INSERT INTO `orders`(`user_id`, `product_id`, `product_quantity`,  `p_name`, `p_brand_name`, `p_discount`, `s_price`, `p_image`, `p_category`, `p_seller`,
        `address_id`, `address_type`, `customer_name`, `street_address`, `landmark`, `contact`, `city`, `state`, `pincode`) VALUES
         ('$user_id','$p_id','$p_quantity','$p_name','$p_brand','$p_discount','$s_price',' $p_image',' $p_cat','$p_seller'
         ,'$_POST[add_num]','$data6[address_type]','$data6[full_name]','$data6[street_address]',
     '$data6[landmark]','$data6[contact]','$data6[city]','$data6[state]','$data6[pin_code]' )";
       $res1=mysqli_query($con,$sql1);
                if($res1){echo "yesss";}
                else{echo "noooo"; error_log(mysqli_error($con),3,"error.txt");}


       
      }   
      
      $sql2="delete from cart";
      $res2=mysqli_query($con,$sql2);
      if($res2){echo
    
        
        "yesss";}
      else{echo "noooo";}   
      
      $sql4="select * from product where product_id='$p_id'";
      $res4=mysqli_query($con,$sql4);
      $data4=mysqli_fetch_assoc($res4);
          $lft=$data4['product_quantity'];
          $lft=$lft-$p_quantity;
      $sql3="UPDATE `product` set product_quantity='$lft' where product_id=$p_id ";
      $res3=mysqli_query($con,$sql3);

        }
        else{
            error_log(mysqli_error($con),3,"error.txt");}
       
      

?>