<?php
session_start();
$z=$_GET["pid"]; 
$uid= $_SESSION["user_id"];

$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="select * from product where product_id=$z";
$res=mysqli_query($con,$sql);
 if($res){ 
       
    $data=mysqli_fetch_assoc($res);
           if($data){
               $p_sellerid=$data['seller_id'];
               $p_name=$data['product_name'];
               $p_brand_name=$data['product_brand_name'];
               $p_description=$data['product_description'];
               $p_detail=$data['product_details'];
               $p_image=$data['product_image'];
               $p_price=$data['product_price'];
               $p_discount=$data['discount'];
               $p_image=$data['product_image'];
			   $p_quantity=$data['product_quantity'];
			   $p_cid=$data['product_category_id'];
         $d=100-$p_discount;
         $n_price =round(($p_price/ 100) * $d);
			   switch ($p_cid) {
				case '0':
					$ct="Electronics";
					break;
				case '1':
				$ct="Edibles";
				break;
				case '2':
				$ct="Men";
				break;
					case '3':
					$ct="Women";
					break;
				case '4':
				$ct="Baby & Kids";
				break;
				case '5':
				$ct="Home & Furniture";
				break;
					case '6':
					$ct="Sports,Books&More";
					break;
			
			}
			
               $con1=mysqli_connect("localhost","root","","cartsea",3306);
                      if(!$con1){
                             die("cant connect to database");
                      }
                     $sql1="select * from seller where seller_id='$p_sellerid'";
                     $res1=mysqli_query($con1,$sql1);
                     if($res1){ 
       
                     $data1=mysqli_fetch_assoc($res1);
                     if($data1){
               $seller_company=$data1['company_name'];  
            }
        }
        else{
            error_log(mysqli_error($con1),3,"error.txt");
        echo "noooo";}
        
            
    }
        
    
        }
        else{
            error_log(mysqli_error($con),3,"error.txt");
        echo "noooo";}

?>
<!doctype html>
<html>
<head>
<link href="https://fonts.googleapis.com/css?family=DM+Serif+Text|Noto+Serif|Roboto|Squada+One|Titillium+Web&display=swap" rel="stylesheet">
<style>
html,body{height:100%;width:100%;}
*{margin:0px;}
h1{margin-left:15px;text-transform: capitalize;}
.x1{padding:18px 32px;border-radius:5px;position:fixed;margin-left:100px;margin-top:480px;font-size:20px;font-weight:bold;background-color:orangered;cursor:pointer;}
.x1:hover{box-shadow: 0px 0px 10px 10px #888888;}
.x2{padding:18px 60px;position:fixed;border-radius:5px;margin-left:320px;margin-top:480px;font-size:20px;font-weight:bold;background-color:#f7b202;cursor:pointer;}
.x1:hover,.x2:hover{box-shadow: 0px 0px 10px 10px #888888;}

</style>            
</head>
<body     background-color: beige;>
<div  style="width:100%; height:8%; background-color:black">
    <img onclick="redirect()"  src="image/lg2.png" style="height:100%;cursor:pointer;" />
  </div >
      <img  style="position:fixed;width:530px;height:400px;margin-left:47px;margin-top:60px;border-radius:10px;" src="<?php echo("http://localhost/eCommerce/".$p_image);?>">
	  <p>
	  <button class="x1" id="addbutton" onclick="xyz('<?php echo($uid)?>','<?php echo($z)?>','<?php echo($p_name);?>','<?php echo($p_brand_name);?>',
    '<?php echo($n_price);?>','<?php echo($seller_company);?>','<?php echo($ct);?>','<?php echo($p_price);?>','<?php echo($p_discount);?>','<?php echo($p_image);?>')" >ADD TO CART</button>
    <button class="x2" id="addbutton" onclick="xyz1('<?php echo($z)?>','<?php echo($p_quantity)?>','<?php echo($p_name);?>','<?php echo($p_brand_name);?>',
    '<?php echo($n_price);?>','<?php echo($seller_company);?>','<?php echo($ct);?>','<?php echo($p_price);?>','<?php echo($p_discount);?>','<?php echo($p_image);?>')" >BUY NOW</button>

</p>

  </div>
  <div  style="width:700px;height:400px;position:absolute;left:44%;top:18%;">
     <h1 style="font-family: 'Noto Serif', serif;font-size:18px ;"><?php echo("$p_brand_name"); ?></h1>
	 <h1 style="font-family: 'Titillium Web', sans-serif;font-size:36px ;"><?php echo("$p_name"); ?>	 <p style="display:inline;font-size:13px ;font-family: 'Roboto', sans-serif;margin-left:15px;"><?php echo("$ct"); ?></h1>
</p>
	 <hr style=" border: 0; height: 1px; background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));"> <br>
	 <h5 style="font-size:29px;margin-left:10px;font-family: 'Roboto', sans-serif;text-transform:capitalize;"><?php
  
   echo("₹".$n_price); ?>&nbsp;&nbsp; <s style="color:brown;font-size:15px"><?php echo("₹".$p_price); ?>  </s>
   <p style="font-size:15px;color:green;display:inline;">&nbsp;&nbsp;<?php echo("$p_discount"); ?>% Off  </p> </h5></br>
   <hr style=" border: 0; height: 2px; background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));"> <br>
    <h1 style="font-family: 'Noto Serif', serif;font-size:10px ;"><b style="font-size:12px;">Description: </b><?php echo($p_description); ?> </h1></br>
	<h1 style="font-family: 'Squada One', cursive;font-size:21px ;">seller: <p style="display:inline;font-family: 'Titillium Web', sans-serif;"><?php echo("₹".$seller_company); ?> </p></h1><br>
	<hr style=" border: 0; height: 1px; background-image: linear-gradient(to right, rgba(0, 0, 0, 0), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0));"> <br>
	<h1 style="font-family: 'Squada One', cursive;font-size:21px ;">Details: <p style="display:inline;font-family: 'Titillium Web', sans-serif;font-size:11px;"><?php echo("₹".$p_detail); ?> </p></h1>




  </div>
  <script>
    function xyz(uid,pid,p_name,p_brand,p_price,p_seller,p_cat,c_price,p_discount,p_image){
             s=document.getElementById('addbutton');
             console.log(uid+pid+p_name+p_brand,+p_price+p_seller+p_cat+c_price+p_discount);
			 s.innerHTML="ADDED TO CART";
       s.style.paddingLeft="8px";s.style.paddingRight="8px";
			 s.style.backgroundColor="green";
			 cx= new XMLHttpRequest();
                     if(cx){
                       cx.open("POST","http://localhost/eCommerce/productbuy_db.php", true);

                      cx.onreadystatechange = () =>{
                        if(cx.readyState == 4){
                          console.log("cx response text", cx.responseText);
                        }

                      }
                      cx.setRequestHeader("Content-Type", "application/x-www-form-urlencoded")
                      cx.send("user_id="+uid+"&p_id="+pid+"&p_name="+p_name+"&p_brand="+p_brand+
      "&p_price="+p_price+"&p_seller="+p_seller+"&p_cat="+p_cat+"&c_price="+c_price+"&p_discount="+p_discount+"&p_image="+p_image);
					 }
           else{
            error_log(mysqli_error($con),3,"error.txt");
       }



	}
  function xyz1(p_id,pq,p_name,p_brand,p_price,p_seller,p_cat,c_price,p_discount,p_image){
    
      window.location.href ="buypage.php?p_id="+p_id+"&sq="+pq+"&p_name="+p_name+"&p_brand="+p_brand+
      "&p_price="+p_price+"&p_seller="+p_seller+"&p_cat="+p_cat+"&c_price="+c_price+"&p_discount="+p_discount+"&p_image="+p_image;

	}
  function redirect(){
        window.location.href = '3_homePage.php';

       } 
  </script>
</body>
</html>