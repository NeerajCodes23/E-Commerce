<?php
session_start();
$z=$_GET["id"];

$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="select * from product where product_id=$z";
$res=mysqli_query($con,$sql);
 if($res){ 
       
    while($data=mysqli_fetch_assoc($res)){
           if($data){
               $p_name=$data['product_name'];
               $p_brand_name=$data['product_brand_name'];
               $p_description=$data['product_description'];
               $p_detail=$data['product_details'];
               $p_image=$data['product_image'];
           }
        
    }
        }
        else{
            error_log(mysqli_error($con),3,"error.txt");
        echo "noooo";}
?>

<!DOCTYPE html>
<html>
<head>
 <style>
     html,body{height:100%;width:100%;}
     *{margin:0px;}
 </style>
</head>
<body>

<div>
    <img src="<?php echo("http://localhost/eCommerce/".$p_image);?>" style="position: absolute;top:27px;width:30%;height:60%;left:5%;">
</div>
      <div style="width:30%;border: 1px solid black;margin-left: 40%;margin-top:27px; text-align: center;">
        <h1 style="font-size:40px;"><?php echo("$p_name"); ?></h1>
            
        </div>
    <div style="width:45%;border: 1px solid black;margin-left: 40%;margin-top:60px;vertical-align: text-top;">
        Brand: <p><?php echo("$p_brand_name"); ?></p></br>
        Description:<p><?php echo("$p_description"); ?></p></br>
        Details:<p><?php echo("$p_detail"); ?></p>
    </div>

    
</body>
</html>