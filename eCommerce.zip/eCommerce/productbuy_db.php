<?php
session_start();
$user_id= $_POST["user_id"];
$p= $_POST["p_id"];
$p_name=$_POST['p_name'];
$p_brand=$_POST['p_brand'];
$p_price=$_POST['p_price'];
$p_seller=$_POST['p_seller'];
$p_cat=$_POST['p_cat'];
$c_price=$_POST['c_price'];
$p_discount=$_POST['p_discount'];
$p_image=$_POST['p_image'];


$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="INSERT INTO `cart`(`user_id`, `product_id`, `product_quantity`, `p_name`, `p_brand_name`, `p_discount`, `c_price`, `s_price`,`p_image`, `p_category`, `seller`) VALUES 
('$user_id','$p',1,'$p_name','$p_brand','$p_discount','$c_price','$p_price','$p_image','$p_cat','$p_seller')";
$res=mysqli_query($con,$sql);
 if($res){ 


        }
        else{
            error_log(mysqli_error($con),3,"error.txt");
        echo "noooo";}



?>