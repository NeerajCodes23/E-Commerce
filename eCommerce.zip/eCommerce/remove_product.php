<?php
session_start();
$z=$_GET['pid'];
echo($z);
$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="delete from product where product_id='$z' " ;
$res=mysqli_query($con,$sql);
 if($res){  echo "ysss ";
     header('Location: seller_product.php');
    ;      
        }
        else{error_log(mysqli_error($con),3,"error.txt");}



?>