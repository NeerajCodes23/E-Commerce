<?php
session_start();
$fn=$_POST['fn'];
$ln=$_POST['ln'];
$co=$cc.$_POST['mb'];
$pass=$_POST['pass'];
$p=$_SESSION['user_id'];
$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="UPDATE `user` set user_first_name='$fn' ,user_last_name='$ln' ,user_mobile_number='$co' ,user_password='$pass' where user_id='$p' ";
$res=mysqli_query($con,$sql);
 if($res){
 
         
                $_SESSION["fn"] = $fn;
                $_SESSION["ln"] =$ln;
                $_SESSION["contact"]=$co;
                $_SESSION["password"]=$pass;
                header('Location: 4_myprofile.php');
 }
 else{  error_log(mysqli_error($con),3,"error.txt");
  

   }
 
 




?>

