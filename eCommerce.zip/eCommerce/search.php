<?php
session_start();
$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
   die("cant connect to database");
  }
$p=$_SESSION['user_id'];

$_SESSION['pcount']=0; 



$query = $_POST['qwer']; 
$_SESSION['search']=$query;
    // gets value sent over search form
     
    $min_length = 2;
    // you can set minimum length of the query if you want
     
    if(strlen($query) >= $min_length){ // if query length is more or equal minimum length then
         
        $query = htmlspecialchars($query); 
        // changes characters used in html to their equivalents, for example: < to &gt;
         
      //  $query = mysql_real_escape_string($query);
        // makes sure nobody uses SQL injection
         
        $raw_results = mysqli_query($con,"SELECT * FROM product
            WHERE (`title` LIKE '%".$query."%') OR (`text` LIKE '%".$query."%')");
             
        // * means that it selects all fields, you can also write: `id`, `title`, `text`
        // articles is the name of our table


        $sql="SELECT * FROM product WHERE (`product_name` LIKE '%".$query."%') OR (`product_brand_name` LIKE '%".$query."%')";
$raw_results=mysqli_query($con,$sql);
$num=mysqli_num_rows($raw_results);
         
        // '%$query%' is what we're looking for, % means anything, for example if $query is Hello
        // it will match "hello", "Hello man", "gogohello", if you want exact match use `title`='$query'
        // or if you want to match just full word so "gogohello" is out use '% $query %' ...OR ... '$query %' ... OR ... '% $query'
         
        if($num > 0){ // if one or more rows are returned do following
             $product_array=array();$i=0;$count=0;
            while($results = mysqli_fetch_array($raw_results)){
            // $results = mysql_fetch_array($raw_results) puts data from database into array, while it's valid it does the loop
             
                echo "<p><h3>".$results['product_name']."</h3>".$results['brand_name']."</p>";

               $product_array[$i]=$results['product_id'];++$i; $count=$i;
                // posts results gotten from database(title and text) you can also show id ($results['id'])
            }
            $_SESSION['aid']=$product_array;
            $_SESSION['pcount']=$count;
        }
        else{ // if there is no matching rows do following
            echo "No results";
            $_SESSION['aid']=null;
            $_SESSION['pcount']=0;        }
       
        // for ($x = 0; $x <$count; $x++) {
        //     echo $product_array[$x];
        //   }


    //     foreach($_SESSION['aid'] as $key=>$value)
    // {
    // // and print out the values
    // echo 'The value of $_SESSION['."'".$key."'".'] is '."'".$value."'".' <br />';
    // }
         
    }
    else{ // if query length is less than minimum
        echo "Minimum length is ".$min_length;
    }


    header('Location: searched_product_page.php');
?>