<?php
session_start();

$p=$_SESSION['seller_id'];
?>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">

<link href="https://fonts.googleapis.com/css?family=Notable|Patua+One|Roboto&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Russo+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="styles.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="script.js"></script> 
  <style>
     html,body{height:100%;width:100%;}
    *{margin:0px;}
     .pk{text-transform:capitalize;text-align:center;}

.button {
  
  border-radius: 4px;
  background-color: red;
  border: none;
  color: #FFFFFF;
  text-align: center;
  font-size: 28px;
  padding: 12px;
  width: 35%;
  transition: all 0.5s;
  cursor: pointer;
  
}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {
  content: '\00bb';
  position: absolute;
  opacity: 0;
  top: 0;
  right: -20px;
  transition: 0.5s;
}

.button:hover span {
  padding-right: 25px;
}

.button:hover span:after {
  opacity: 1;
  right: 0;
}
  </style>
</head>
<div id='cssmenu' bgcolor="black">
<ul>
   <li ><a href='9_seller_dashboard.php'><span>Dashboard</span></a></li>
   <li><a href='seller_product.php'><span>My Products</span></a></li>
   <li class='active'><a href='seller_order.php'><span>Orders</span></a></li>
   <li><a href='logout_seller.php'><span>Log Out</span></a></li>
   <li style="position:absolute;right:100px;"><a  style="font-size:40px;font-family: 'Russo One', sans-serif;
   padding:20px;background-color:blue;"><span>Seller's Point</span></a></li>
</ul>

</div>

            <div style="width:100%; height:8%; background-color:white; width:85%;height:50%;margin-top:40px;margin-left:110px;   ">
                    <div style="background-color:orange;width:100%;height:50px;border-radius:4px; border: 2px solid;">
                             <p style=" text-align:center;font-family: 'Russo One', sans-serif;font-size: 37px;" >Orders Received</p>                                                                                    

                    </div> 
                    
                    
                    <div class="container" >
                            <div class="table-responsive">          
                            <table class="table">
                              <thead>
                                 <tr style="font-size:18px;">
                                    <th class="pk">Product Image</th>
                                    <th class="pk">Product Name</th>
                                    <th class="pk">Product Brand</th>
                                    <th class="pk">Product Quantity</th>  
                                    <th class="pk">Product Price</th>
                                    <th class="pk">Discount(%)</th>
                                    <th class="pk">Customer</th>
                                   
                                   
                                </tr>
                               </thead>
                            <tbody>
                           
                           <?php
                                $con=mysqli_connect("localhost","root","","cartsea",3306);
                                if(!$con){
                                   die("cant connect to database");
                                  }
                                  
                             $sql="select orders.p_name,orders.p_image,orders.p_brand_name,orders.product_quantity,orders.s_price,orders.p_discount,
                             orders.customer_name from orders,product where product.seller_id='$p'  and orders.product_id=product.product_id";
                              $res=mysqli_query($con,$sql);
                              
                              if($res){         $u=-1;$total=0;
                                while($data=mysqli_fetch_assoc($res)){
                                  $q=$data["p_image"];++$u;$total=$total+($data['s_price']*$data['product_quantity']);
                                  ?>
                                  <tbody>
                                   <tr>       
                                   <td class="pk"><img style="width:200px;height:200px;margin-left:50%;transform:translateX(-50%);" src="<?php echo str_replace(" ","","http://localhost/eCommerce/".$q);?>"></td>
                                             <td class="pk" style="vertical-align: inherit;"><?php echo($data['p_name']); ?></td>
                                             <td class="pk" style="vertical-align: inherit;"><?php echo($data['p_brand_name']); ?></td>
                                             <td  class="pk" style="vertical-align: inherit;"> <?php echo($data['product_quantity']); ?> </td>
                                             <td  class="pk" style="vertical-align: inherit;"><?php echo("₹".$data['s_price']); ?></td>
                                             <td class="pk"  style="vertical-align: inherit;"><?php echo($data['p_discount']."%"); ?></td>
                                             <td class="pk"  style="vertical-align: inherit;"><?php echo($data['customer_name']); ?></td>
                                             <!-- <td><img src="<?php echo("http://localhost/eCommerce/".$q);?>" alt="" border=3 height=50 width=50></img></td> -->
                                             
                            </tr></tbody>
                                 <?php 
                                }}
                                else{echo "noooooooooo"; error_log(mysqli_error($con),3,"error.txt");}
                                ?> 
                        

                </div>



    <script>
    //  function redirect(){
    //     window.location.href = '3_homePage.php';

    //    } 
    </script>
</body>
</html>