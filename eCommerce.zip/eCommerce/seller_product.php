<?php
session_start();
echo($_SESSION['full_name']);
?>
<!DOCTYPE html>
<html>

<head>
<link href="https://fonts.googleapis.com/css?family=Francois+One&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css?family=Russo+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
<link href="https://fonts.googleapis.com/css?family=Russo+One&display=swap" rel="stylesheet">
<link rel="stylesheet" href="styles.css">
<script src="http://code.jquery.com/jquery-latest.min.js" type="text/javascript"></script>
<script src="script.js"></script>  

  <style>
    html,body {width: 100%;height: 100%;}
    * { margin: 0px;} 
    .c1{display: inline-block; width:95%;height:30px;margin-top: 20px;border-color: darkgray; border-radius: 5px;
     vertical-align: top;}
     .clickme { background-color: #EEEEEE;font-size:30px;padding: 20px 20px;text-decoration:none;font-weight:bold;
     border-radius:5px;cursor:pointer;margin-left:76%;
}

.danger {
    background-color:#FF0040;
    color: #FFFFFF;
}
.danger:hover {
    background-color:#EB003B;
    color: #FFFFFF;
}
   </style>
</head>
<body>
<div id='cssmenu' bgcolor="black">
<ul>
   <li ><a href='9_seller_dashboard.php'><span>Dashboard</span></a></li>
   <li class='active'><a href='#'><span>My Products</span></a></li>
   <li><a href='seller_order.php'><span>Orders</span></a></li>
   <li><a href='logout_seller.php'><span>Log Out</span></a></li>
   <li style="position:absolute;right:100px;"><a  style="font-size:40px;font-family: 'Russo One', sans-serif;
   padding:20px;background-color:blue;"><span>Seller's Point</span></a></li>
</ul>
</div><br><br>
<div class="c1" style="font-family: 'Russo One', sans-serif; ">
              <a  href="add_product.php" style="text-decoration:none;" class="clickme danger" >   
                ADD PRODUCT 
              </a>  
        </div>
        
<div class="container" style="">
  <h2 style=" text-align:center;font-family: 'Russo One', sans-serif;" >MY PRODUCT LIST</h2>                                                                                    
  <div class="table-responsive">          
  <table class="table">
    <thead>
       <tr style="font-size:18px;">
          <th>Product Name</th>
          <th>Product Brand</th>
          <th>Product Id</th>
          <th>Product Quantity</th>  
          <th>Product Price</th>
          <th>Discount(%)</th>
          <th>Product Detail</th>
          <th>Delete</th>
      </tr>
     </thead>
  <tbody>
 
 <?php
      $con=mysqli_connect("localhost","root","","cartsea",3306);
      if(!$con){
         die("cant connect to database");
        }
   $p=$_SESSION['seller_id'];
   $sql="select * from product where seller_id='$p'";
    $res=mysqli_query($con,$sql);
    if($res){         
      while($data=mysqli_fetch_assoc($res)){
        $q=$data["product_image"];
        $o=$data['product_id'];
        ?>
        <tbody name="tb">
         <tr name="tr">
                   <td><?php echo($data['product_name']); ?></td>
                   <td><?php echo($data['product_brand_name']); ?></td>
                   <td><?php echo($data['product_id']); ?></td>
                   <td><?php echo($data['product_quantity']); ?></td>
                   <td><?php echo($data['product_price']); ?></td>
                   <td><?php echo($data['discount']); ?></td>
                   
         
                   <!-- <td><img src="<?php echo("http://localhost/eCommerce/".$q);?>" alt="" border=3 height=50 width=50></img></td> -->
                   <td name="td"><a name="lk" onclick="showp(<?php  echo($o);   ?>)" >click here</a></td>
                   <td><a onclick="removep(<?php  echo($o);   ?>) " >remove</a></td>

  </tr></tbody>
       <?php 
      }}
      else{echo "noooooooooo";}
      ?> 
      <script>
    //         (function (d) {
        
    //     // Get the table element
    //     var table = function() {
    //       var tables = d.getElementsByTagName('table');
    //       return tables[tables.length - 1];
    //     }();
   
    //     table.onclick = function (e) {
    //       var target = e.target;
   
    //       // If an <a> was clicked
    //       if( target.nodeName.toLowerCase() === 'a' ) {
   
    //         // Find the tr containing that a
    //         var node = target;
    //         while (node.nodeName.toLowerCase() !== 'tr' )
    //           node = node.parentNode;
    //         var tr = node;
   
    //         // Output the contents of the table cells in that row
    //         var cells = tr.cells;
           
    //             var g=cells[2].innerHTML;
    //             window.location.href = "product_detail_seller.php?id=" + g;
    //             //  console.log($_SESSION['id']);
   
    //         // Return false to prevent the link from loading
            
    //       }
    //     }
    //  })(document)

                function removep(pid){
                  window.location.href = "remove_product.php?pid=" +pid; 

                }

                function showp(pid){console.log("dfghgfd");
                  window.location.href = "product_detail_seller.php?id=" + pid;

                }
      </script>

 

 

</table>
  </div>
</div>


</body>
</html>




