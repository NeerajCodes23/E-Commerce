<?php
session_start();
$fn=$_POST['first_name'];
$ln=$_POST['last_name'];
$cc=$_POST['countrycode'];
$co=$cc.$_POST['contact'];
$em=$_POST['email'];
$pass=$_POST['password'];
$gender=$_POST['q1'];

echo "$dob";
$con=mysqli_connect("localhost","root","","cartsea",3306);
if(!$con){
     die("cant connect to database");
     }
$sql="INSERT INTO `user`( `user_first_name`, `user_last_name`,`user_gender`, `user_email_id`, `user_password`, `user_mobile_number`) 
VALUES ('$fn','$ln','$gender','$em','$pass',$co)";
$res=mysqli_query($con,$sql);
 if($res){
    $sql1="select user_id from user where user_email_id='$em'";
    $res1=mysqli_query($con,$sql1);
         
      
              if($data=mysqli_fetch_assoc($res1)){ 
                $xyz=$data[user_id];
                echo($xyz);
                 echo($em);
                $_SESSION["user_name"] =$em;
                $_SESSION["user_id"] = $xyz;
                $_SESSION["fn"] = $fn;
                $_SESSION["ln"] =$ln;
                $_SESSION["contact"]=$co;
                $_SESSION["password"]=$pass;
                $_SESSION["gender"]=$gender;
                header('Location: 3_homePage.php');
                }

            
      header('Location: 3_homePage.php');
 }
 else{  error_log(mysqli_error($con),3,"error.txt");
    header('Location: 2_signup.php');

   }
 
 




?>

